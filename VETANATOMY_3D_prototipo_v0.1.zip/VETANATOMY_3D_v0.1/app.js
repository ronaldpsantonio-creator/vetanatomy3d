const speciesData={
  Equino:{icon:"🐎",note:"El caballo es un herbívoro no rumiante; su anatomía digestiva presenta particularidades importantes."},
  Bovino:{icon:"🐄",note:"El bovino es rumiante y posee rumen, retículo, omaso y abomaso."},
  Porcino:{icon:"🐖",note:"El cerdo es un monogástrico omnívoro; presenta diferencias anatómicas propias de la especie."}
};
const summaries={
 "Óseo":"El sistema óseo proporciona sostén, protección y palancas para el movimiento. Estudiaremos esqueleto axial y apendicular, huesos y accidentes óseos.",
 "Muscular":"El sistema muscular permite el movimiento, mantiene la postura y contribuye a la producción de calor. Se estudiarán grupos musculares, origen, inserción y acción.",
 "Digestivo":"El sistema digestivo participa en la ingestión, digestión y absorción de nutrientes. Su organización cambia entre equinos, bovinos y porcinos.",
 "Respiratorio":"El sistema respiratorio conduce el aire y permite el intercambio gaseoso. Incluye cavidad nasal, faringe, laringe, tráquea, bronquios y pulmones.",
 "Circulatorio":"El sistema circulatorio transporta sangre, gases, nutrientes y productos de desecho. Incluye corazón, arterias, venas y capilares.",
 "Nervioso":"El sistema nervioso coordina funciones sensoriales, motoras y viscerales. Comprende sistema nervioso central y periférico.",
 "Urinario":"El sistema urinario participa en la eliminación de desechos y regulación del equilibrio hídrico y electrolítico.",
 "Reproductor":"El sistema reproductor comprende órganos genitales masculinos y femeninos, con diferencias anatómicas específicas entre especies."
};
let selectedSpecies="Equino", selectedSystem="Óseo";
const $=s=>document.querySelector(s);
function render(){
 const sp=speciesData[selectedSpecies];
 $("#species-note").textContent=`Especie seleccionada: ${selectedSpecies}. ${sp.note}`;
 $("#animal-icon").textContent=sp.icon;
 $("#viewer-title").textContent=`Modelo ${selectedSpecies.toLowerCase()} · Sistema ${selectedSystem.toLowerCase()}`;
 $("#study-title").textContent=`${selectedSpecies} · Sistema ${selectedSystem.toLowerCase()}`;
 let extra=selectedSpecies==="Bovino"&&selectedSystem==="Digestivo"?" En el bovino se estudiarán los cuatro compartimentos gástricos: rumen, retículo, omaso y abomaso.":selectedSpecies==="Equino"&&selectedSystem==="Digestivo"?" En el equino se prestará especial atención al intestino grueso y sus características.":selectedSpecies==="Porcino"&&selectedSystem==="Digestivo"?" En el porcino se estudiará el estómago simple y la organización intestinal propia de la especie.":"";
 $("#study-text").textContent=summaries[selectedSystem]+extra;
 document.querySelectorAll(".species-btn").forEach(b=>b.classList.toggle("selected",b.dataset.species===selectedSpecies));
 document.querySelectorAll(".system-btn").forEach(b=>b.classList.toggle("active",b.dataset.system===selectedSystem));
}
document.querySelectorAll(".species-btn").forEach(b=>b.addEventListener("click",()=>{selectedSpecies=b.dataset.species;render()}));
document.querySelectorAll(".system-btn").forEach(b=>b.addEventListener("click",()=>{selectedSystem=b.dataset.system;render()}));
$("#rotate").addEventListener("click",()=>alert("El control de rotación real se activará al integrar el visor y el modelo anatómico 3D."));
$("#layers").addEventListener("click",()=>alert("Las capas se activarán cuando incorporemos un modelo 3D separado en mallas anatómicas."));
if("serviceWorker" in navigator){window.addEventListener("load",async()=>{try{await navigator.serviceWorker.register("./service-worker.js");$("#connection").textContent="Preparada para modo offline";}catch(e){$("#connection").textContent="Modo offline pendiente";}})}
render();